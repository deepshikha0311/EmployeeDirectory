package test.jio.rjil.com.mainprojectjson;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private Button button_log;
    private EditText edit_id_login, edit_name_login;
    private String id_login;
   private String name;
    private HttpURLConnection connection;
    private String jsonResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button_log = findViewById(R.id.button_login);
        edit_id_login = findViewById(R.id.id_login);
        edit_name_login = findViewById(R.id.name_login);

        button_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MyTask().execute();


            }

        });

    }

    public class MyTask extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... strings) {
            try {
                id_login = edit_id_login.getText().toString();
                URL url = new URL("http://dummy.restapiexample.com/api/v1/employee/" + id_login);

                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.connect();

                BufferedReader bf = new BufferedReader(new InputStreamReader(url.openStream()));

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = bf.readLine()) != null) {
                    sb.append(line);
                }
                jsonResponse = sb.toString();
                connection.disconnect();
                bf.close();

               JSONObject jresponse = new JSONObject(jsonResponse);
//                response = jresponse.getString("employee_name");
                //Item item =  new Gson().fromJson(jsonResponse, Item.class);
                name=jresponse.getString("employee_name");
                Log.d("TAG","XXXXX",null);



            } catch (Exception e1) {
                e1.printStackTrace();

                return null;
            }
            return name;
        }

        @Override
        protected void onPostExecute(String name) {
            super.onPostExecute(name);
            String x = edit_name_login.getText().toString();

            if (!TextUtils.isEmpty(name) && name.equals(x)) {

                Intent i = new Intent(MainActivity.this, EmployeeDetails.class);
                startActivity(i);
            } else {
                Toast.makeText(MainActivity.this, "server problem", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

