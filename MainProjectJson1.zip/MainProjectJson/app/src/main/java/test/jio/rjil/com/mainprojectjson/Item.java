package test.jio.rjil.com.mainprojectjson;

import com.google.gson.annotations.SerializedName;

public class Item {

   // @SerializedName("employee_name")
   private String id;
    private String employee_name;
    private String employee_salary;
    private String employee_age;


    public String getId() {
        return id;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public String getEmployee_salary() {
        return employee_salary;
    }

    public String getEmployee_age() {
        return employee_age;
    }

    public Item(String id, String employee_name, String employee_salary, String employee_age) {
        this.id = id;
        this.employee_name = employee_name;
        this.employee_salary = employee_salary;
        this.employee_age = employee_age;
    }
}
